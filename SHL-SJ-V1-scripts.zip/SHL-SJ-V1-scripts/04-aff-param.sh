#!/bin/bash
clear
echo "Nom du processus en cours :" $0
echo "Valeur du 1er paramètre transmis :" $1
echo "Valeur du 2ème paramètre transmis :" $2
echo "Valeur du 3ème paramètre transmis :" $3
echo "Nombre de paramètres transmis :" $#
echo "Liste de tous les paramètres transmis :" $*
