#!/bin/bash
date >> ~/sauve-date.txt
