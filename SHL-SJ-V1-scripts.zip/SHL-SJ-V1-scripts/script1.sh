#!/bin/bash
echo "script 1"
