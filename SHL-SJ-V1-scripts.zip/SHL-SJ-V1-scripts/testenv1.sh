#!/bin/bash
echo $mavar ; mafonction
./testenv2.sh
