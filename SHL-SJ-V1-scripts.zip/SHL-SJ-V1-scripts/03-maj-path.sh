#!/bin/bash
clear
read -p "Saisissez le chemin absolu contenant vos programmes : " chemin
PATH=$PATH:$chemin
echo "La variable système PATH contient maintenant :" $PATH
