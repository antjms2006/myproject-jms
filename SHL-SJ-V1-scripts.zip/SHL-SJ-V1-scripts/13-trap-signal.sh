#!/bin/bash
# signal 2 intercepté avec commandes (INT, CTRL+C)
trap 'clear ; echo "signal 2 intercepté avec commandes"' 2
read
