#!/bin/bash
echo $mavar ; mafonction
