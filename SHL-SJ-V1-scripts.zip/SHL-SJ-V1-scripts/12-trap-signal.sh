#!/bin/bash
# signal 2 désactivé (INT, CTRL+C)
trap '' 2
read
