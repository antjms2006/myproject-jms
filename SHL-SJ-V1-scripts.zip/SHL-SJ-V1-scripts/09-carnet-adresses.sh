#!/bin/bash
saisie()
{
    clear
    echo "SAISIE D'UN CONTACT"
    echo
    read -p "Nom : " nom
    read -p "Prénom : " prenom
    read -p "Rue : " rue
    read -p "Code postal : " codepostal
    read -p "Commune : " commune
    read -p "Téléphone : " telephone
    echo
    contact=$nom';'$prenom';'$rue';'$codepostal';'$commune';'$telephone
    echo $contact >> carnet-adresses.txt
    echo "Contact enregistré."
    read
}

recherche()
{
    clear
    echo "RECHERCHE D'UN CONTACT"
    echo
    read -p "Critère de recherche : " critere
    echo
    echo "Résultat :"
    echo
    grep -i $critere carnet-adresses.txt | sort | more
    read
}

liste()
{
    clear
    echo "LISTE DES CONTACTS"
    echo
    cat carnet-adresses.txt | sort | more
    read
}

quitte()
{
    exit
}

erreur()
{
    echo
    echo "ERREUR"
    read
    choix='£' # pour while (si vide)
}

choix='£' # pour while

while [ $choix != 'q' ]
    do
        clear
        echo "CARNET D'ADRESSES"
        echo
        echo "MENU"
        echo "s - saisie"
        echo "r - recherche"
        echo "l - liste"
        echo "q - quitter"
        echo
        read -p "Choix> " choix
        
        case $choix
            in
            's')
                saisie
                ;;
            'r')
                recherche
                ;;
            'l')
                liste
                ;;
            'q')
                quitte
                ;;
            *)
                erreur
                ;;
        esac
    done
