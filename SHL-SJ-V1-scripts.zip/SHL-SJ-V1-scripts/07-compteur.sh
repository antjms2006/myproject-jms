#!/bin/bash
compteur=1
while [ $compteur -le 1000 ]
    do
        clear
        echo $compteur
        # compteur=`expr $compteur + 1`
        compteur=$((compteur + 1))
    done
