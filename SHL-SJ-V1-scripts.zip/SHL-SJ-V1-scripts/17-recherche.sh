#!/bin/bash
clear
for fichier in `find $2 -type f`
   do
      grep -H -n -i $1 $fichier
   done
