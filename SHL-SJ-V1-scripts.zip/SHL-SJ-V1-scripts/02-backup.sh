#!/bin/bash
# rappel : on peut utiliser $HOME ou ~
clear
mkdir $HOME/backups 2> backups.err
cp -r -u -v $1 $HOME/backups 2>> backups.err
echo
echo "Contenu du répertoire $HOME/backups :"
ls -la $HOME/backups | more
echo
echo "Traitement terminé. Erreur(s) rencontrée(s) :"
echo
more backups.err
