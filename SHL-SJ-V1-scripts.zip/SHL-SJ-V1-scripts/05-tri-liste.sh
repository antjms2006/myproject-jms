#!/bin/bash
sauvetriliste() {
   echo $* | tr ' ' $'\n' | sort > tri-liste.txt
}

affichetriliste() {
   # cat tri-liste.txt | more
   more tri-liste.txt
}

clear
sauvetriliste $*
affichetriliste

echo ; echo $# "paramètre(s) trié(s)." ; echo
