#!/bin/bash
secret=`expr $RANDOM \* 99 / 32767`
nombre=0
coups=0
clear
echo "Trouvez le nombre secret compris entre 1 et 99..."
echo

while [ $nombre -ne $secret ]
   do
      coups=`expr $coups + 1`
      read -p "Essai $coups : nombre secret ? " nombre
      if [ $nombre -gt $secret ]
         then
            echo "TROP GRAND !"
      fi
      if [ $nombre -lt $secret ]
         then
            echo "TROP PETIT !"
      fi
   done

echo
echo "BRAVO ! $secret trouvé en $coups coup(s)."
echo

