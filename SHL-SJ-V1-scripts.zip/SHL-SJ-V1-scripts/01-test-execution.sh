#!/bin/sh
clear
echo "Shell et commande utilisés (uniquement sur Linux) :"
# /proc : infos système (noyau) - $$ : PID du processus en cours
cat /proc/$$/cmdline
echo
