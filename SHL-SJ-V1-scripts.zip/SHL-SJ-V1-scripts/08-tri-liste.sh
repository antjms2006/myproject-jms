#!/bin/bash
sauvetriliste() {
   echo $* | tr ' ' $'\n' | sort > tri-liste.txt
}

affichetriliste() {
   # cat tri-liste.txt | more
   more tri-liste.txt
}

if [ $# -eq 0 ]
   then
      echo "Erreur de syntaxe: paramètres manquants"
      exit 1
   else
      if [ $1 = "-l" ]
         then
            affichetriliste
         else
            sauvetriliste $*
            echo $# "paramètre(s) trié(s)."
      fi
fi
