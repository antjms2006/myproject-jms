#!/bin/bash
clear
read -p "Veuillez saisir votre nom : " nom
if [ $nom = "Dupont" ]
    then
        echo "OK"
    else
        echo "KO"
fi
