#!/bin/bash
clear
echo
echo -n "Texte à défiler : "
read texte
echo -n "Vitesse de défilement : "
read vitesse

espaces='____________________________________________'
longaff=${#espaces}
texte0=$espaces$texte
longmax=`expr ${#texte0} - 1`
texte=$espaces$texte$espaces
position=0

while [ $fin != $FIN ]
   do
      clear
      affichage=${texte:position:longaff}
      echo
      echo $affichage
      echo
      sleep $vitesse
      
      if [ $position -gt $longmax ]
         then
            position=0
         else
            position=`expr $position + 1`
      fi
   done

