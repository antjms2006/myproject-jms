#!/bin/bash
wc -l ; echo "suite" ; wc -l
