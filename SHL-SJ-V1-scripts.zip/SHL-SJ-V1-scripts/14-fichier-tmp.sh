#!/bin/bash
# fichier temporaire supprimé quand signal 2 (INT, CTRL+C)
trap '[ -e .fichier-tmp.tmp ] && rm -f .fichier-tmp.tmp ; exit' 2
touch .fichier-tmp.tmp
ls -la .fichier-tmp.tmp
read
