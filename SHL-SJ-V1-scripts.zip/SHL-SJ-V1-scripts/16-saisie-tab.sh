#!/bin/bash
read -p "Nombre de valeurs à saisir : " nb
for i in `seq 1 $nb`
   do read -p "Saisissez la valeur $i : " tab[$i]
done
i=1
for val in ${tab[*]}
   do echo "La valeur $((i++)) vaut :" $val
done
