#!/bin/bash
echo "script 2"
